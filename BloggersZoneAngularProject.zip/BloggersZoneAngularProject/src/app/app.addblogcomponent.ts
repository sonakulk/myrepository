import{Component} from '@angular/core';
import { OnInit } from '@angular/core';
import { BlogService } from './app.blogservices';
import { Blog } from './app.blog';
import { FormGroup, FormControl ,Validators,FormBuilder} from '@angular/forms';



@Component({
    selector:'add-blog',
    templateUrl:'app.addblog.html'
})
export class AddBlog {

   blogs:Blog[];  
   model:any ={};
   msg:string="Blog added successfully..";
   emailRegex = '^[a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,15})$';

//  addBlogForm = this.fb.group({
//     title: [''],
//    type: [''],
//    content:[''],
//      id: [''],
//      name: [''],
//       email:[''],
//      mobileNumber:['']
    
//   });
addBlogForm = this.fb.group({
    title: ['',[Validators.required]],
   type: ['',[Validators.required]],
   content:['',[Validators.required]],
     id: ['',[Validators.required]],
     name: ['',[Validators.required]],
      email:['',[Validators.required]],
     mobileNumber:['',[Validators.required]]
    
  });
  


//  addBlogForm = new FormGroup({
//     title: new FormControl('',Validators.required),
//     type: new FormControl('',Validators.required),
//     content: new FormControl('',Validators.required),
//       id: new FormControl('',Validators.required),
//       name: new FormControl('',Validators.required),
//       email: new FormControl('',Validators.required),
//       mobileNumber: new FormControl('',Validators.required)
    
//   });
  



constructor(private blogservice:  BlogService,private fb: FormBuilder){
   // console.log("prod constructor");
}


addBlog()
{
    this.model.title=this.addBlogForm.value.title;
     this.model.type=this.addBlogForm.value.type;
        this.model.content=this.addBlogForm.value.content;
           this.model.id=this.addBlogForm.value.id;
              this.model.name=this.addBlogForm.value.name;
                 this.model.email=this.addBlogForm.value.email;
                 this.model.mobileNumber=this.addBlogForm.value.mobileNumber;

    console.log(this.model);
     // window.alert(this.msg);
    this.blogservice.addBlog(this.model).subscribe((data:any)=>console.log(data));
  
 alert("data added");
    
   
  
}
// addBlog()
// {
//    
//     console.log(this.model);
//      // window.alert(this.msg);
//     this.blogservice.addBlog(this.model).subscribe((data:any)=>console.log(data));
    
  
// }
}