import{Blogger} from './app.blogger';


export class Blog{

    title:string;
    content:string;
    type:string;
    time:Date;
    blogger:Blogger;

}