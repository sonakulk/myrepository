import{Component} from '@angular/core';
import { OnInit } from '@angular/core';
import { BlogService } from './app.blogservices';
import { Blog } from './app.blog';
import { FormGroup, FormControl ,Validators,FormBuilder} from '@angular/forms';



@Component({
    selector:'searchbyblogger-blog',
    templateUrl:'app.searchbyblogger.html'
})
export class SearchBlogByBlogger {

name:string;
   blogs:Blog[];  
    error:string='';
    searchByBloggerBlogForm = this.fb.group({
    name: [''],  
  });

 
constructor(private blogservice:  BlogService,private fb: FormBuilder){
   // console.log("prod constructor");
}

searchByBloggerName(){
console.log(this.blogs);
 this.blogservice.searchByBloggerName(this.searchByBloggerBlogForm.value.name).subscribe((data:any)=>this.blogs=data,  error => {
        this.error = error;
      });
}


}