package com.cg.BloggersZoneSpringBootDataJPA.controller;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.BloggersZoneSpringBootDataJPA.dto.Blog;
import com.cg.BloggersZoneSpringBootDataJPA.exceptions.BlogException;
import com.cg.BloggersZoneSpringBootDataJPA.services.BlogService;
/*This is MyController class this work as controller for whole application 
 * Modified on 24-05-2019
 * @author	Sonal Kulkarni
 * 
 * 
 * */
//@RestController
@RestController
@RequestMapping("/bloggerszone")
public class MyController {
	/* Autowired the IBlogService object. */
	@Autowired
	BlogService service;

	/* This method map to http://localhost:9090/bloggerszone//addblog
	 * @param @ModelAttribute blog
	 * @return blog
	 * @author	Sonal Kulkarni
	 * 
	 * */
	@RequestMapping(value="/addblog",method=RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Blog> addBlog( @ModelAttribute("blog") Blog blog) throws SQLException {
		blog.setTime(new Timestamp(System.currentTimeMillis()));
		Blog blogg=service.addBlog(blog);	
		return new ResponseEntity<Blog>(blogg,HttpStatus.OK);
	}

	/* This method map to http://localhost:9090/bloggerszone//searchbytitle
	 * @param @RequestParam title
	 * @return List<Blog>
	 * @author	Sonal Kulkarni
	 * */
	@RequestMapping(value="/searchbytitle",method=RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Blog>> searchBlog(@RequestParam("title") String title)
	{
		List<Blog> mylist =service.searchByTitle(title);	
		return  new ResponseEntity<List<Blog>>(mylist,HttpStatus.OK);

	}
	/* This method map to http://localhost:9090/bloggerszone//searchbybloggername
	 * @param @RequestParam name
	 * @return List<Blog>
	 * @author	Sonal Kulkarni
	 * 
	 */
	@RequestMapping(value="/searchbybloggername",method=RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Blog>> searchByBlogger(@RequestParam("name") String name)
	{
		List<Blog> mylist =service.searchByBloggerName(name);	
		return  new ResponseEntity<List<Blog>>(mylist,HttpStatus.OK);

	}
	/* This method map to http://localhost:9090/bloggerszone//addbyexistblogger
	 * @param @ModelAttribute blog
	 * @return blog
	 * @author	Sonal Kulkarni
	 * 
	 * */

	@RequestMapping(value="/addbyexistblogger",method=RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Blog> addBlogByExistingBlogger(@ModelAttribute("blog") Blog blog) throws SQLException {
		blog.setTime(new Timestamp(System.currentTimeMillis()));
		Blog blogg=service.addExistBlog(blog);
		return new ResponseEntity<Blog>(blogg,HttpStatus.OK);
	}
	/*This is @ExceptionHandler method
	 * Handles @BlogException
	 * @author	Sonal Kulkarni
	 */
	@ExceptionHandler({BlogException.class})
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<String> handleBlogException(BlogException be) {
		return  new ResponseEntity<String>(be.getMessage(),HttpStatus.NOT_FOUND);

	} 







}
