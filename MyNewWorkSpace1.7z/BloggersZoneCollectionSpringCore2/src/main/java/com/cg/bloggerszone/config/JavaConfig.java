package com.cg.bloggerszone.config;

import org.springframework.context.annotation.ComponentScan;

import org.springframework.context.annotation.Configuration;
/*This is JavaConfig class which is responsible for creating Beans of all the classes under given package. .
 * 
 * @author	Sonal Kulkarni
 * 
 * 
 * */
@Configuration
@ComponentScan(basePackages="com.cg.bloggerszone")
public class JavaConfig {
	

}
