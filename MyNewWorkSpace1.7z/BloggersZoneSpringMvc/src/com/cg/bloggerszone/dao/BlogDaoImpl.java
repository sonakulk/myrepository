package com.cg.bloggerszone.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.exceptions.BlogException;
import com.cg.bloggerszone.util.DBUtil;

/*This is repository class which is responsible database operations.
 * 
 * @author	Sonal Kulkarni
 * 
 * 
 * */
@Repository("dao")     //This anotation is used to create Repository bean.

public class BlogDaoImpl implements IBlogDao{
	static final Logger logger = Logger.getLogger(BlogDaoImpl.class);

	public BlogDaoImpl() {}


	/** 
	 * This method is used to save the blog added by the blogger. 
	 * 
	 * */
	
	public Blog saveBlog(Blog blog) {
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\MyNewWorkSpace\\BloggersZoneCollectionSpringCore2\\src\\main\\resources\\log4j.properties");
		Blog b =findById(blog.getBlogger().getId());
		if(b==null) {
			DBUtil.blogs.add(blog);}
		else {			
			blog.setBlogger(b.getBlogger());
			DBUtil.blogs.add(blog);
		}
		logger.info("adding the blog"+blog);
		return blog ;	
	}
	/** 
	 * This method is used to search the blogger . 
	 * @param title this parameter is used to find the blogs by given title
	 * */
	public List<Blog> findByTitle(String title) {
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\MyNewWorkSpace\\BloggersZoneCollectionSpringCore2\\src\\main\\resources\\log4j.properties");
		List<Blog> bloglist = new ArrayList<Blog>();
		for(Blog blog:DBUtil.blogs) {
			if(blog.getTitle().toLowerCase().contains(title))
			{

				bloglist.add(blog);	}
		}
		logger.info("Searching  the blog by title");
		return  bloglist;		
	}

	/** 
	 * This method is used to search the blogger . 
	 * @param name this parameter is used to find the blogs by given BloggerName
	 * */
	public List<Blog> findByBloggerName(String name) 
	{
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\MyNewWorkSpace\\BloggersZoneCollectionSpringCore2\\src\\main\\resources\\log4j.properties");
		List<Blog> mybloglist = new ArrayList<Blog>();		
		for(Blog blog:DBUtil.blogs) {
			if(blog.getBlogger().getName().toLowerCase().contains(name)) 
				mybloglist.add(blog);				
		}
		logger.info("Searching  the blog by blogger name");
		return mybloglist;
	}
	/** 
	 * This method is used to search the blogger . 
	 * @param id this parameter is used to find the blogs by given bloggeid.
	 * */
	public Blog findById(int id) {
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\MyNewWorkSpace\\BloggersZoneCollectionSpringCore2\\src\\main\\resources\\log4j.properties");
		for(Blog blog: DBUtil.blogs) {
			if(blog.getBlogger().getId()==id) {
				return blog;	}
		}
		return null;
	}
}
