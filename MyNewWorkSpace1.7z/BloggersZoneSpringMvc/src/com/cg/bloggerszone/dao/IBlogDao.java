package com.cg.bloggerszone.dao;


import java.util.List;

import com.cg.bloggerszone.dto.Blog;


public interface IBlogDao {
	
	public Blog saveBlog(Blog blog);
	
	public List<Blog> findByTitle(String title);

	public List<Blog> findByBloggerName(String name);
	public Blog findById(int id);

}
