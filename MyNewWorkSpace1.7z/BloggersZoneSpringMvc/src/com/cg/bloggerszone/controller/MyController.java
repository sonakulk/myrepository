package com.cg.bloggerszone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.service.IBlogService;

@Controller
public class MyController {
	@Autowired
	IBlogService service;
	
	@GetMapping("listpage")
	public String loginPage() {
		return "listpage";		
	}
	
	@GetMapping("addblog")
	public ModelAndView getBlog(@ModelAttribute ("blog") Blog blog) {
		return new ModelAndView("addblog");
		
	}
	@PostMapping("addblog")
	public ModelAndView addBlog(@ModelAttribute("blog")Blog blog) {
		
		Blog b=service.addBlog(blog);
		return new ModelAndView("success","addblog",b);		
	}
	@GetMapping("searchbytitle")
	public ModelAndView searchBlog() {
		return new ModelAndView("searchbytitle");
		
	}
	@PostMapping("searchbytitle")
	public ModelAndView searchByTitle(@RequestParam("title")String title,Model m) {
		
		List<Blog> b=service.searchByTitle(title);
		m.addAttribute("blog", b);
		return new ModelAndView("searchbytitle");		
	}

	@GetMapping("searchbybloggername")
	public ModelAndView searchBlogByName() {
		return new ModelAndView("searchbybloggername");
		
	}
	@PostMapping("searchbybloggername")
	public ModelAndView searchByBlogger(@RequestParam("name")String name,Model m) {
		
		List<Blog> b=service.searchByBloggerName(name);
		m.addAttribute("blog", b);
		return new ModelAndView("searchbybloggername");	
		
	}
}
