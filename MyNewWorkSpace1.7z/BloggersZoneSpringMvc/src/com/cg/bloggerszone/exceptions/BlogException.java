package com.cg.bloggerszone.exceptions;

import org.springframework.stereotype.Component;


public class BlogException extends RuntimeException {

	public BlogException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BlogException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
