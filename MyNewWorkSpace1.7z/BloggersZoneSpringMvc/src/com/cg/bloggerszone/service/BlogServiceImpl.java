package com.cg.bloggerszone.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.cg.bloggerszone.dao.BlogDaoImpl;
import com.cg.bloggerszone.dao.IBlogDao;
import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.exceptions.BlogException;
/*This is Service class which is responsible Business Logic .
 * 
 * @author	Sonal Kulkarni
 * 
 * 
 * */
@Service("service")						//This anotation is used to create Service bean.

public class BlogServiceImpl implements IBlogService {
	@Autowired
	IBlogDao dao;
	static final Logger logger = Logger.getLogger(BlogServiceImpl.class);
	public BlogServiceImpl() {}
	/** 
	 * This method is used to save the blog added by the blogger. 
	 * 
	 * */
	public Blog addBlog(Blog blog) {
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\MyNewWorkSpace\\BloggersZoneCollectionSpringCore2\\src\\main\\resources\\log4j.properties");
		logger.info("adding the blog"+blog);
		return dao.saveBlog(blog);
	}
	/** 
	 * This method is used to search the blogger . 
	 * @param title this parameter is used to find the blogs by given title
	 * @BlogException is throwing 
	 * */
	public List<Blog> searchByTitle(String title) {	
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\MyNewWorkSpace\\BloggersZoneCollectionSpringCore2\\src\\main\\resources\\log4j.properties");
		logger.info("Searching  the blog by title");
		List<Blog> bloglist=dao.findByTitle(title);
		if(bloglist.isEmpty()) {
			logger.warn(" blogs not found blogException is thrown");
			throw new BlogException("Blogs with this title not found");}
		return dao.findByTitle(title);}
	/** 
	 * This method is used to search the blogger . 
	 * @param name this parameter is used to find the blogs by given BloggerName
	 * @BlogException is throwing 
	 * */
	public List<Blog> searchByBloggerName(String name) {	
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\MyNewWorkSpace\\BloggersZoneCollectionSpringCore2\\src\\main\\resources\\log4j.properties");
		logger.info("Searching  the blog by blogger name");
		List<Blog> bloglist=dao.findByBloggerName(name);
		if(bloglist.isEmpty()) {
			logger.warn(" blog with this blogger name blogException is thrown");
			throw new BlogException("Blogs of this blogger not found");}
		return dao.findByBloggerName(name);
	}

	/** 
	 * This method is used to search the blogger . 
	 * @param id this parameter is used to find the blogs by given bloggeid.
	 * @BlogException is throwing 
	 * */
	public Blog searchById(int id) {
		logger.info("Searching  the blog by id");
		Blog b=dao.findById(id);
			if(b==null) {
				logger.warn(" id not found blogException is thrown");
				throw new BlogException("id not found");}
		return b;
	}

}
