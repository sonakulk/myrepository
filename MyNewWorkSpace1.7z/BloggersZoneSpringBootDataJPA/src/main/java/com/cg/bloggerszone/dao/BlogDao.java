package com.cg.bloggerszone.dao;


import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.util.Queries;

/*This is repository interface which contains  abstract methods for database operations.
 * 
 * @author	Sonal Kulkarni
 *  Modified on 19-05-2019
 * 
 * */
public interface BlogDao extends JpaRepository<Blog, Integer> {	
	
	public Blog saveExistBlog(Blog blog);
	
	@Query(Queries.searchByTitle)
	public List<Blog> findByTitle(String title);

	@Query(Queries.searchByBloggerName)
	public List<Blog> findByBloggerName(String name);

}
