package com.cg.bloggerszone.util;
/*This is Quesries interface which is responsible storing the JPQL queries.
 * 
 * @author	Sonal Kulkarni
 * Modified on 19-05-2019
 * 
 * */
public interface Queries {

	public static String  searchByTitle="FROM Blog b WHERE b.title Like :title";
	public static String  searchByBloggerName="SELECT b from Blog b ,IN (b.blogger) br WHERE br.name LIKE ?1";
	
}
