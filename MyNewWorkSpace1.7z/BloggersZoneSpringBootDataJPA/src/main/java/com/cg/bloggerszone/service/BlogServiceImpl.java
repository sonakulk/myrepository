package com.cg.bloggerszone.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bloggerszone.dao.BlogDao;


import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.exceptions.BlogException;


/*This is Service class which is responsible Business Logic .
 * 
 * @author	Sonal Kulkarni
 *  Modified on 19-05-2019
 * */
@Service							//This anotation is used to create Service bean.
@Transactional
public class BlogServiceImpl implements BlogService {

	@Autowired
	BlogDao dao;
	Blog blog;
	static final Logger logger = Logger.getLogger(BlogServiceImpl.class);
	public BlogServiceImpl() {}
	/** 
	 * This method is used to save the blog added by the existing blogger. 
	 * @param blog
	 * @return Blog 
	 * @throws SQLException 
	 * */
	@Override
	public Blog addBlog(Blog blog) throws SQLException {
		return dao.save(blog);
	}
	
	/** 
	 * This method is used to search the blogger . 
	 * @param title this parameter is used to find the blogs by given title
	 * @throws BlogException 
	 * */
	public List<Blog> searchByTitle(String title) {	
		List<Blog> bloglist=dao.findByTitle(title);
		if(bloglist.isEmpty()) {
			logger.warn("blogs not found blog exception is thrown");
			throw new BlogException("Blogs with this title not found");}
		return dao.findByTitle(title);
	}
	/** 
	 * This method is used to search the blogger . 
	 * @param name this parameter is used to find the blogs by given bloggername.
	 * @throws BlogException 
	 * */
	public List<Blog> searchByBloggerName(String name) {
		List<Blog> bloglist=dao.findByBloggerName(name);
		if(bloglist.isEmpty()) {
			logger.warn("blogs not found blog exception is thrown");
			throw new BlogException("Blogs of this blogger not found");}
		return dao.findByBloggerName(name);
	}
	/** 
	 * This method is used to save the blog added by the  blogger. 
	 * @param blog
	 * @return Blog 
	 * Throws @BlogException 
	 * */
	public Blog addExistBlog(Blog blog) throws SQLException  {

		return dao.saveExistBlog(blog);
	}
}
