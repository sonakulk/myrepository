package com.cg.BloggersZoneSpringBootDataJPA.dto;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
/*The class Blogger contains all the basic important details of the blogger
 * such as id,name,email,mobileNumber
 *  and the getters and setters of all.
 * 
 * Last Modified 23/05/2019  06.30 p.m.
 * @author	Sonal Kulkarni
 * */
@Entity
public class Blogger {
	
	@Id
	@Column(name="blogger_id")			
	private Integer id;										//this attribute is used to store id of the blogger
	@Column(name="blogger_name")
	private String name;									//this attribute is used to store name of the blogger
	@Column(name="email")
	private String email;									//this attribute is used to store email of the blogger
	@Column(name="mobilenumber")
	private BigInteger mobileNumber;						//this attribute is used to store mobilenumber of the blogger
	
	public Blogger() {
		super();		
	}
	
	public Blogger(Integer id, String name, String email, BigInteger mobileNumber) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.mobileNumber = mobileNumber;
	}
	
	public Integer getId() {
		return id;                                                                                                                                               
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public BigInteger getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	@Override
	public String toString() {
		return "Blogger [id=" + id + ", name=" + name + ", email=" + email + ", mobileNumber=" + mobileNumber + "]";
	}
		
}
