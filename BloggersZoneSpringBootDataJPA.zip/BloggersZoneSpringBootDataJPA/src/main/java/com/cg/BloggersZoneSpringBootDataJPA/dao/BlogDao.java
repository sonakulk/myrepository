package com.cg.BloggersZoneSpringBootDataJPA.dao;


import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.BloggersZoneSpringBootDataJPA.dto.Blog;
import com.cg.BloggersZoneSpringBootDataJPA.dto.Blogger;
import com.cg.BloggersZoneSpringBootDataJPA.util.Queries;

/*This is repository interface which contains  abstract methods for database operations.
 * 
 * @author	Sonal Kulkarni
 *  Modified on 25-05-2019
 * 
 * */
public interface BlogDao extends JpaRepository<Blog, Integer> {	
	
	
	@Query(Queries.searchByTitle)
	public List<Blog> findByTitleContaining(String title);

	@Query(Queries.searchByBloggerName)
	public List<Blog> findByName(String name);
	
	@Query("from Blogger b where b.id = :id")
	public Blogger findByBloggerId(int id);
	
	public Blog findByTitle(String title);

}
