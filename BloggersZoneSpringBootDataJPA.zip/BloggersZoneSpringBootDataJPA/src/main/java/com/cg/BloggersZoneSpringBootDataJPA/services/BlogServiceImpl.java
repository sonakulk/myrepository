package com.cg.BloggersZoneSpringBootDataJPA.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.BloggersZoneSpringBootDataJPA.dao.BlogDao;
import com.cg.BloggersZoneSpringBootDataJPA.dto.Blog;
import com.cg.BloggersZoneSpringBootDataJPA.dto.Blogger;
import com.cg.BloggersZoneSpringBootDataJPA.exceptions.BlogException;



@Service							//This anotation is used to create Service bean.
@Transactional
public class BlogServiceImpl implements BlogService {

	@Autowired
	BlogDao blogdao;
	Blog blog;
	static final Logger logger = Logger.getLogger(BlogServiceImpl.class);
	public BlogServiceImpl() {}
	/** 
	 * This method is used to save the blog added by the  blogger. 
	 * @param blog
	 * @return Blog 
	 * Throws @BlogException 
	 * */
	@Override
	public Blog addBlog(Blog blog) throws SQLException {
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\BloggersZoneSpringBootDataJPA\\src\\main\\resources\\log4j.properties");
		Blog blogg=blogdao.findByTitle(blog.getTitle());
		Blogger blogger=searchByBloggerId(blog.getBlogger().getId()); 
		if(blogg!=null) {
			logger.warn("blog title already exist");
			throw new BlogException("title already exist");}
		if(blogger==null) {
			blogdao.save(blog);	
			logger.info("Blog is added");
		}
		else {
			logger.warn("Blogger Id is already Exist");
			throw new BlogException("blogger Id already exist");
		}
		return blog;
	}

	/** 
	 * This method is used to search the blogger . 
	 * @param title this parameter is used to find the blogs by given title
	 * @return List<Blog>
	 * @throws BlogException 
	 * */
	public List<Blog> searchByTitle(String title) {	
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\BloggersZoneSpringBootDataJPA\\src\\main\\resources\\log4j.properties");
		List<Blog> bloglist=blogdao.findByTitleContaining(title);
		if(bloglist.isEmpty()) {
			logger.warn("blogs not found blog exception is thrown");
			throw new BlogException("Blogs with this title not found");}
		return blogdao.findByTitleContaining(title);
	}
	/** 
	 * This method is used to search the blogger . 
	 * @param name this parameter is used to find the blogs by given blogger name
	 * @return List<Blog>
	 * @throws BlogException 
	 * */
	public List<Blog> searchByBloggerName(String name) {
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\BloggersZoneSpringBootDataJPA\\src\\main\\resources\\log4j.properties");
		List<Blog> bloglist=blogdao.findByName(name);
		if(bloglist.isEmpty()) {
			logger.warn("blogs not found blog exception is thrown");
			throw new BlogException("Blogs of this blogger not found");}
		return blogdao.findByName(name);
	}
	/** 
	 * This method is used to save the blog added by the existing blogger. 
	 * @param blog
	 * @return Blog 
	 * @throws BlogException 
	 * */
	
	public Blog addExistBlog(Blog blog)  {
		PropertyConfigurator.configure("D:\\Sonalk\\Study\\BloggersZoneSpringBootDataJPA\\src\\main\\resources\\log4j.properties");
		Blogger blogger=searchByBloggerId(blog.getBlogger().getId()); 
		Blog blogg=blogdao.findByTitle(blog.getTitle());
		if(blogg!=null) {
			logger.warn("blog title already exist");
			throw new BlogException("title already exist");}
		if(blogger==null) 
		{
			logger.warn("Blogger Id not exist");
			throw new BlogException("Blogger Id not exist");
		}
		blog.setBlogger(blogger);
		logger.info("Blog is added with existing blogger");
		return blogdao.save(blog);
				
	}
	
	/** 
	 * This method is used to save the blog added by the existing blogger. 
	 * @param id
	 * @return Blogger 
	 * */
	public Blogger searchByBloggerId(int id) {
		return blogdao.findByBloggerId(id);		
	}
	
}
